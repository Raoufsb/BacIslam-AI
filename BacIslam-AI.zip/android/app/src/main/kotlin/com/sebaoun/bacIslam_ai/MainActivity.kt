package com.sebaoun.bacIslam_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
