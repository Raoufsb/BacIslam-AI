// ═══════════════════════════════════════════════════════════════
// setup_screen.dart
// ─────────────────────────────────────────────────────────────
// تظهر هذه الشاشة فقط عند أول تشغيل (أو إذا لم يُخزَّن مفتاح API).
// وظيفتها بسيطة: أخذ مفتاح Google AI Studio من المستخدم وحفظه،
// ثم الانتقال إلى شاشة الدردشة.
// ═══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/storage_service.dart';
import 'loading_screen.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final TextEditingController _apiKeyController = TextEditingController();
  String? _errorText;

  @override
  void dispose() {
    _apiKeyController.dispose();
    super.dispose();
  }

  Future<void> _openTutorialVideo() async {
    // رابط تعليمي عام يشرح كيفية الحصول على مفتاح مجاني من Google AI Studio.
    // يمكنك استبداله برابط الفيديو الخاص بك.
    final uri = Uri.parse('https://aistudio.google.com/app/apikey');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _startUsingApp() async {
    final key = _apiKeyController.text.trim();

    // التحقق من أن الحقل غير فارغ
    if (key.isEmpty) {
      setState(() => _errorText = 'الرجاء إدخال المفتاح أولاً');
      return;
    }

    // حفظ المفتاح محلياً
    await StorageService.saveApiKey(key);

    if (!mounted) return;

    // الانتقال إلى شاشة التحميل (تجهّز النماذج وقاعدة RAG) وإزالة
    // شاشة الإعداد من المكدس حتى لا يستطيع المستخدم الرجوع إليها.
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const LoadingScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // شعار التطبيق (أيقونة بسيطة بدل صورة خارجية)
              const Icon(Icons.school_rounded, size: 90, color: Colors.teal),
              const SizedBox(height: 16),
              const Text(
                'نور البكالوريا',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 32),
              const Text(
                'أدخل مفتاح Google AI Studio',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _apiKeyController,
                obscureText: true,
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: 'ألصق المفتاح هنا...',
                  errorText: _errorText,
                  border: const OutlineInputBorder(),
                ),
                onChanged: (_) {
                  if (_errorText != null) setState(() => _errorText = null);
                },
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _startUsingApp,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text('بدء الاستخدام', style: TextStyle(fontSize: 16)),
                ),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: _openTutorialVideo,
                child: const Text('كيف أحصل على مفتاح مجاني؟'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}