// ═══════════════════════════════════════════════════════════════
// chat_screen.dart
// ─────────────────────────────────────────────────────────────
// شاشة الدردشة الرئيسية، مبنية على حزمة flutter_gen_ai_chat_ui
// (واجهة احترافية جاهزة: فقاعات، Streaming كتابة تدريجية، Markdown،
// دعم RTL كامل) بدل بناء الفقاعات يدوياً.
//
// كل رد من الذكاء الاصطناعي يظهر معه:
//   - تنبيه صغير: "هذا نموذج ذكاء اصطناعي وقد ينتج عنه أخطاء"
//   - زر "إبلاغ" يفتح بريد المستخدم لإرسال شكوى عن الرد المحدد
//     (يلبّي متطلبات Google Play بخصوص المحتوى المولَّد بالذكاء
//     الاصطناعي: إفصاح مستمر + آلية إبلاغ عن المحتوى).
// ═══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:flutter_gen_ai_chat_ui/flutter_gen_ai_chat_ui.dart';
import 'package:url_launcher/url_launcher.dart';

import '../constants/system_prompt.dart';
import '../services/gemini_service.dart';
import '../services/rag_service.dart';
import '../services/storage_service.dart';

// البريد الذي تُرسل إليه بلاغات المستخدمين عن ردود غير مناسبة/خاطئة.
const String _kReportEmail = 'raoufsebaoun@gmail.com';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late ChatMessagesController _controller;
  final ChatUser _currentUser = ChatUser(id: 'user', firstName: 'أنت');
  final ChatUser _aiUser = ChatUser(id: 'ai', firstName: 'الأستاذ');

  // تاريخ المحادثة بصيغة بسيطة (دور/نص)، منفصل عن تحكّم واجهة الدردشة.
  // نستخدمه لبناء طلبات Gemini (system_instruction + تاريخ كامل) ولحفظ
  // المحادثة محلياً، دون الاعتماد على تفاصيل داخلية في الحزمة الجاهزة.
  final List<Map<String, String>> _conversation = [];

  bool _isLoading = false;
  String? _apiKey;

  @override
  void initState() {
    super.initState();
    _controller = ChatMessagesController();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    final key = await StorageService.getApiKey();
    final history = await StorageService.loadChatHistory();

    for (final m in history) {
      _conversation.add({'role': m.isUser ? 'user' : 'model', 'text': m.text});
      _controller.addMessage(ChatMessage(
        text: m.text,
        user: m.isUser ? _currentUser : _aiUser,
        createdAt: DateTime.now(),
      ));
    }

    if (mounted) setState(() => _apiKey = key);
  }

  Future<void> _persistHistory() async {
    final data = _conversation
        .map((m) => ChatMessageData(text: m['text']!, isUser: m['role'] == 'user'))
        .toList();
    await StorageService.saveChatHistory(data);
  }

  void _clearConversation() {
    setState(() {
      _conversation.clear();
      _controller = ChatMessagesController();
    });
    StorageService.clearChatHistory();
  }

  /// يفتح تطبيق البريد لدى المستخدم لإرسال بلاغ عن رد معيّن.
  Future<void> _reportMessage(String messageText) async {
    final uri = Uri(
      scheme: 'mailto',
      path: _kReportEmail,
      queryParameters: {
        'subject': 'إبلاغ عن رد في تطبيق نور البكالوريا',
        'body': 'الرد المُبلَّغ عنه:\n\n$messageText',
      },
    );
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      }
    } catch (_) {
      // فشل فتح تطبيق البريد (نادر): لا داعي لإيقاف التطبيق أو إظهار خطأ مربك.
    }
  }

  Future<void> _handleSendMessage(ChatMessage message) async {
    final question = message.text.trim();
    if (question.isEmpty || _isLoading || _apiKey == null) return;

    final apiKey = _apiKey!;
    // نسخة من المحادثة قبل إضافة هذا السؤال، تُستخدم لإعادة الصياغة
    // ولبناء تاريخ المحادثة الكامل المُرسل لنموذج الإجابة.
    final priorConversation = List<Map<String, String>>.from(_conversation);
    _conversation.add({'role': 'user', 'text': question});

    setState(() => _isLoading = true);

    try {
      // ── الخطوة 0: إعادة صياغة السؤال بالاعتماد على سياق المحادثة ──
      final rewrittenQuestion = await GeminiService.rewriteQuery(
        apiKey,
        question,
        priorConversation,
      );

      // ── الخطوة 1: تضمين السؤال (بعد إعادة الصياغة) ────────
      final queryEmbedding =
          await GeminiService.embedText(apiKey, rewrittenQuestion);

      // ── الخطوة 2: البحث في قاعدة RAG المحمّلة مسبقاً ──────
      // (التحميل/التحديث من GitHub يحصل في شاشة التحميل عند فتح التطبيق)
      final entries = await RagService.loadEntries();
      final matches = RagService.findTopMatches(queryEmbedding, entries);

      // ── الخطوة 3: بناء system_instruction (شخصية + سياق RAG) ──
      String systemInstruction = kSystemPrompt;
      if (matches.isNotEmpty) {
        final contextBlocks = matches
            .asMap()
            .entries
            .map((e) => '[${e.key + 1}]:\n${e.value.text}')
            .join('\n\n---\n\n');

        systemInstruction +=
            '\n\n━━━━━━━━━━━━━━━━━━\n'
            '📖 معلومات مرجعية (لا تُشر إليها — استخدمها فقط لتحسين دقة ردك)\n'
            '━━━━━━━━━━━━━━━━━━\n$contextBlocks';
      }

      // ── الخطوة 4: بناء تاريخ المحادثة الكامل وتوليد الإجابة ───
      final contents = [
        ...priorConversation.map(
          (m) => GeminiService.buildContent(m['role']!, m['text']!),
        ),
        GeminiService.buildContent('user', question),
      ];

      final answer = await GeminiService.generateAnswer(
        apiKey: apiKey,
        contents: contents,
        systemInstruction: systemInstruction,
      );

      // ── الخطوة 5: تسجيل الأسئلة الضعيفة (بدون تطابق قوي كافٍ) ──
      if (RagService.isWeakMatch(matches)) {
        await StorageService.addWeakQuestion(question);
      }

      _conversation.add({'role': 'model', 'text': answer});
      _controller.addMessage(ChatMessage(
        text: answer,
        user: _aiUser,
        createdAt: DateTime.now(),
      ));
    } catch (e) {
      final errorText =
          'تعذّر الحصول على إجابة. تحقق من اتصالك بالإنترنت أو من صحة المفتاح.\n($e)';
      _conversation.add({'role': 'model', 'text': errorText});
      _controller.addMessage(ChatMessage(
        text: errorText,
        user: _aiUser,
        createdAt: DateTime.now(),
      ));
    } finally {
      if (mounted) setState(() => _isLoading = false);
      await _persistHistory();
    }
  }

  /// يضيف تنبيهاً صغيراً وزر إبلاغ تحت كل رد من الذكاء الاصطناعي.
  Widget _wrapAiBubble(Widget defaultBubble, String messageText) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        defaultBubble,
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  '⚠️ هذا نموذج ذكاء اصطناعي وقد ينتج عنه أخطاء',
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                  textAlign: TextAlign.right,
                ),
              ),
              TextButton.icon(
                onPressed: () => _reportMessage(messageText),
                style: TextButton.styleFrom(
                  padding: EdgeInsets.zero,
                  minimumSize: const Size(0, 0),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                icon: Icon(Icons.flag_outlined,
                    size: 14, color: Colors.grey.shade600),
                label: Text(
                  'إبلاغ',
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('نور البكالوريا'),
        actions: [
          IconButton(
            tooltip: 'حذف المحادثة',
            icon: const Icon(Icons.delete_outline),
            onPressed: _clearConversation,
          ),
        ],
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: AiChatWidget(
          currentUser: _currentUser,
          aiUser: _aiUser,
          controller: _controller,
          onSendMessage: _handleSendMessage,
          loadingConfig: LoadingConfig(isLoading: _isLoading),
          enableMarkdownStreaming: true,
          streamingWordByWord: true,
          inputOptions: const InputOptions(
            hintText: 'اكتب سؤالك هنا...',
            sendOnEnter: true,
          ),
          welcomeMessageConfig: const WelcomeMessageConfig(
            title: 'أهلاً بك في نور البكالوريا',
            questionsSectionTitle: 'جرّب تسأل:',
          ),
          exampleQuestions: const [
            ExampleQuestion(question: 'ما معنى التوحيد؟'),
            ExampleQuestion(question: 'اشرح لي مفهوم العقل في القرآن الكريم'),
          ],
          messageOptions: MessageOptions(
            bubbleBuilder: (context, message, isCurrentUser, defaultBubble) {
              if (isCurrentUser) return defaultBubble;
              return _wrapAiBubble(defaultBubble, message.text);
            },
          ),
        ),
      ),
    );
  }
}