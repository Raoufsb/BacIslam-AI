// ═══════════════════════════════════════════════════════════════
// loading_screen.dart
// ─────────────────────────────────────────────────────────────
// تظهر هذه الشاشة في كل مرة يُفتح فيها التطبيق (بعد التأكد من وجود
// مفتاح API)، وقبل الدخول لشاشة الدردشة. مهمتها:
//   1) جلب أسماء النماذج الحالية من GitHub (models.json).
//   2) التحقق من تحديثات قاعدة معرفة RAG وتحميلها عند الحاجة،
//      مع عرض شريط تقدّم فعلي أثناء التحميل.
// ═══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';

import '../services/gemini_service.dart';
import '../services/rag_service.dart';
import 'chat_screen.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});

  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  String _status = 'جاري تجهيز التطبيق...';
  // -1 = مؤشر غير محدد (indeterminate)، 0.0-1.0 = نسبة تقدّم فعلية
  double _progress = -1;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  Future<void> _prepare() async {
    // ── الخطوة 1: تحديث أسماء النماذج من GitHub (في كل فتح تطبيق) ──
    if (mounted) {
      setState(() {
        _status = 'جاري تحديث إعدادات النماذج...';
        _progress = -1;
      });
    }
    await GeminiService.loadModelConfigFromGitHub();

    // ── الخطوة 2: تحديث قاعدة معرفة RAG مع شريط تقدّم حقيقي ──────
    if (mounted) {
      setState(() {
        _status = 'جاري تحديث قاعدة المعرفة...';
        _progress = 0.0;
      });
    }
    await RagService.checkAndDownloadUpdates(
      onProgress: (p) {
        if (!mounted) return;
        setState(() {
          _status = 'جاري تحميل قاعدة المعرفة... ${(p * 100).toStringAsFixed(0)}٪';
          _progress = p;
        });
      },
    );

    if (!mounted) return;

    // الانتقال إلى شاشة الدردشة (نزيل شاشة التحميل من المكدس).
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const ChatScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.school_rounded, size: 72, color: Colors.teal),
                const SizedBox(height: 12),
                const Text(
                  'نور البكالوريا',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 32),
                Text(_status, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                _progress < 0
                    ? const LinearProgressIndicator()
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(
                          value: _progress,
                          minHeight: 8,
                        ),
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}