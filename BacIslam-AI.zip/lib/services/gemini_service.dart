// ═══════════════════════════════════════════════════════════════
// gemini_service.dart
// ─────────────────────────────────────────────────────────────
// كل ما يخص التواصل المباشر مع Google AI (Gemini) موجود هنا:
//   1) loadModelConfigFromGitHub -> يجلب أسماء النماذج من GitHub
//   2) embedText     -> تحويل نص إلى متجه أرقام (embedding)
//   3) rewriteQuery   -> إعادة صياغة سؤال بالاعتماد على سياق المحادثة
//   4) generateAnswer -> توليد الإجابة النهائية (مع system_instruction
//                         ومع كامل تاريخ المحادثة، حتى "يتذكر" النموذج)
// ═══════════════════════════════════════════════════════════════

import 'dart:convert';
import 'package:http/http.dart' as http;

import 'storage_service.dart';

class GeminiService {
  // ── مصدر أسماء النماذج (GitHub) ────────────────────────────
  static const String _repoBase =
      'https://raw.githubusercontent.com/Raoufsb/BacIslam-AI/refs/heads/main';
  static const String _modelsConfigUrl = '$_repoBase/models.json';

  // النماذج المستخدمة — قيم افتراضية احتياطية تُستعمل فقط إذا فشل
  // جلب models.json من GitHub (مثلاً بسبب انقطاع الإنترنت).
  static String _embeddingModel = 'gemini-embedding-2';
  static String _generationModel = 'gemini-3.1-flash-lite';
  static String _rewriteModel = 'gemma-4-31b-it';

  static const String _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  /// يجلب أسماء النماذج من ملف models.json على GitHub، ويحفظ آخر نسخة
  /// ناجحة محلياً. إذا تعذّر الوصول لـ GitHub (لا إنترنت مثلاً)، يستعمل
  /// آخر نسخة محفوظة محلياً من فتحة سابقة — وليس القيم الافتراضية
  /// القديمة المضمّنة بالكود — حتى يبقى تغيير النموذج من GitHub تغييراً
  /// دائماً فعلياً، لا يتراجع بسبب انقطاع الإنترنت المؤقت.
  ///
  /// شكل الملف المتوقع في المستودع:
  /// {"embedding_model": "...", "generation_model": "...", "rewrite_model": "..."}
  static Future<void> loadModelConfigFromGitHub() async {
    try {
      final response = await http
          .get(Uri.parse(_modelsConfigUrl))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        await _applyCachedModelConfig();
        return;
      }

      final data = jsonDecode(utf8.decode(response.bodyBytes));
      _embeddingModel = data['embedding_model'] as String? ?? _embeddingModel;
      _generationModel =
          data['generation_model'] as String? ?? _generationModel;
      _rewriteModel = data['rewrite_model'] as String? ?? _rewriteModel;

      // نحفظ هذا الإعداد الناجح محلياً ليُستعمل لاحقاً عند انقطاع الإنترنت.
      await StorageService.saveModelConfig({
        'embedding_model': _embeddingModel,
        'generation_model': _generationModel,
        'rewrite_model': _rewriteModel,
      });
    } catch (e) {
      // فشل الوصول لـ GitHub: نستعمل آخر نسخة محفوظة محلياً بدل التراجع
      // فوراً للقيم الافتراضية المضمّنة بالكود.
      await _applyCachedModelConfig();
    }
  }

  /// يطبّق آخر إعداد نماذج محفوظ محلياً (إن وُجد). إذا لم يوجد أي إعداد
  /// محفوظ من قبل (أول تشغيل بدون إنترنت مثلاً)، تبقى القيم الافتراضية
  /// المضمّنة بالكود كما هي (آخر ملاذ فقط).
  static Future<void> _applyCachedModelConfig() async {
    final cached = await StorageService.getModelConfig();
    if (cached == null) return;
    _embeddingModel = cached['embedding_model'] ?? _embeddingModel;
    _generationModel = cached['generation_model'] ?? _generationModel;
    _rewriteModel = cached['rewrite_model'] ?? _rewriteModel;
  }

  static Exception _apiError(String context, Object e) {
    return Exception('$context: $e');
  }

  /// يحوّل نص السؤال إلى متجه أرقام (List<double>) عبر Embedding API.
  static Future<List<double>> embedText(String apiKey, String text) async {
    final url = Uri.parse(
      '$_baseUrl/$_embeddingModel:embedContent?key=$apiKey',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'model': 'models/$_embeddingModel',
          'content': {
            'parts': [
              {'text': text}
            ]
          },
        }),
      );

      if (response.statusCode != 200) {
        throw _apiError(
          'فشل تضمين السؤال (كود ${response.statusCode})',
          response.body,
        );
      }

      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final List values = data['embedding']['values'];
      return values.map((e) => (e as num).toDouble()).toList();
    } catch (e) {
      throw _apiError('تعذّر الاتصال بخدمة التضمين', e);
    }
  }

  /// يعيد صياغة سؤال المستخدم الأخير ليصبح مستقلاً وواضحاً بالاعتماد على
  /// آخر عدة رسائل من المحادثة. يُستخدم فقط للتضمين والبحث في RAG،
  /// وليس للإجابة النهائية.
  static Future<String> rewriteQuery(
    String apiKey,
    String question,
    List<Map<String, String>> history, {
    int historyTurns = 4,
  }) async {
    if (history.isEmpty) return question;

    final recent = history.length > historyTurns
        ? history.sublist(history.length - historyTurns)
        : history;

    final historyText = recent.map((t) {
      final speaker = t['role'] == 'user' ? 'التلميذ' : 'الأستاذ';
      return '$speaker: ${t['text']}';
    }).join('\n');

    final prompt =
        'بناءً على سياق المحادثة التالية، أعد صياغة سؤال التلميذ الأخير '
        'ليكون سؤالاً واضحاً ومستقلاً بالكامل (لا يحتاج سياقاً إضافياً).\n'
        'أجب بالسؤال المعاد صياغته فقط، بدون أي شرح أو مقدمة.\n\n'
        '[سياق المحادثة]\n$historyText\n\n'
        '[سؤال التلميذ الأخير]\n$question\n\n'
        '[السؤال المعاد صياغته]';

    final url = Uri.parse(
      '$_baseUrl/$_rewriteModel:generateContent?key=$apiKey',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {'text': prompt}
              ]
            }
          ],
          'generationConfig': {
            'temperature': 0.0,
            'maxOutputTokens': 128,
          },
        }),
      );

      if (response.statusCode != 200) return question;

      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final candidates = data['candidates'] as List?;
      if (candidates == null || candidates.isEmpty) return question;

      final parts = candidates[0]['content']['parts'] as List;
      final buffer = StringBuffer();
      for (final part in parts) {
        if (part['thought'] == true) continue; // نتجاهل تفكير النموذج الداخلي
        if (part['text'] != null) buffer.write(part['text']);
      }
      final rewritten = buffer.toString().trim();
      return rewritten.isNotEmpty ? rewritten : question;
    } catch (e) {
      return question; // أي خطأ شبكة: نتراجع بهدوء للسؤال الأصلي
    }
  }

  /// يبني عنصر "محتوى" واحد بصيغة Gemini API من دور ونص.
  /// role يجب أن تكون 'user' أو 'model'.
  static Map<String, dynamic> buildContent(String role, String text) => {
        'role': role,
        'parts': [
          {'text': text}
        ],
      };

  /// يولّد الإجابة النهائية. يستقبل:
  /// - contents: كامل تاريخ المحادثة (بما فيه آخر سؤال) بصيغة Gemini،
  ///   حتى "يتذكر" النموذج الأسئلة والأجوبة السابقة في نفس الجلسة.
  /// - systemInstruction: تعليمات النظام (شخصية الأستاذ + أي سياق RAG).
  static Future<String> generateAnswer({
    required String apiKey,
    required List<Map<String, dynamic>> contents,
    String? systemInstruction,
  }) async {
    final url = Uri.parse(
      '$_baseUrl/$_generationModel:generateContent?key=$apiKey',
    );

    try {
      final body = <String, dynamic>{
        'contents': contents,
        'generationConfig': {
          'temperature': 0.4,
          'maxOutputTokens': 2048,
        },
      };

      if (systemInstruction != null && systemInstruction.trim().isNotEmpty) {
        body['system_instruction'] = {
          'parts': [
            {'text': systemInstruction}
          ],
        };
      }

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (response.statusCode != 200) {
        throw _apiError(
          'فشل توليد الإجابة (كود ${response.statusCode})',
          response.body,
        );
      }

      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final candidates = data['candidates'] as List?;
      if (candidates == null || candidates.isEmpty) {
        throw _apiError('لم يُرجع النموذج أي إجابة', data);
      }

      final parts = candidates[0]['content']['parts'] as List;
      final buffer = StringBuffer();
      for (final part in parts) {
        // نتجاهل أجزاء "التفكير الداخلي" للنموذج (thought: true) ونأخذ
        // فقط النص النهائي، حتى لا يختلط تفكير النموذج مع الجواب الفعلي.
        if (part['thought'] == true) continue;
        if (part['text'] != null) buffer.write(part['text']);
      }
      return buffer.toString().trim();
    } catch (e) {
      throw _apiError('تعذّر الاتصال بخدمة توليد الإجابة', e);
    }
  }
}