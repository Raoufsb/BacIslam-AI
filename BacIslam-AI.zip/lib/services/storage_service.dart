// ═══════════════════════════════════════════════════════════════
// storage_service.dart
// ─────────────────────────────────────────────────────────────
// هذا الملف مسؤول عن كل عمليات الحفظ والاسترجاع المحلي:
//   - مفتاح Google AI Studio (API Key)
//   - إصدار ملف RAG المخزّن محلياً (لمقارنته مع GitHub)
//   - قائمة الأسئلة "الضعيفة" (التي لم نجد لها سياقاً في RAG)
//   - تاريخ المحادثة (حتى لا تضيع عند إغلاق التطبيق)
//
// نجمّع كل هذا المنطق في مكان واحد حتى لا نكرر أكواد
// SharedPreferences في كل شاشة على حدة (مبدأ فصل المسؤوليات).
// ═══════════════════════════════════════════════════════════════

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ChatMessageData {
  final String text;
  final bool isUser; // true = المستخدم، false = الذكاء الاصطناعي

  ChatMessageData({required this.text, required this.isUser});

  Map<String, dynamic> toJson() => {'text': text, 'isUser': isUser};

  factory ChatMessageData.fromJson(Map<String, dynamic> json) =>
      ChatMessageData(text: json['text'], isUser: json['isUser']);
}

class StorageService {
  // مفاتيح التخزين (نستخدم ثوابت حتى نتجنب أخطاء الطباعة اليدوية)
  static const _keyApiKey = 'api_key';
  static const _keyRagVersion = 'rag_version';
  static const _keyWeakQuestions = 'weak_questions';
  static const _keyChatHistory = 'chat_history';
  static const _keyModelConfig = 'model_config';

  // ── مفتاح API ──────────────────────────────────────────────
  static Future<void> saveApiKey(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyApiKey, key);
  }

  static Future<String?> getApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyApiKey);
  }

  static Future<void> clearApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyApiKey);
  }

  // ── إصدار RAG المخزّن محلياً ───────────────────────────────
  static Future<String?> getLocalRagVersion() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyRagVersion);
  }

  static Future<void> setLocalRagVersion(String version) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyRagVersion, version);
  }

  // ── الأسئلة الضعيفة (التي لم يُعثر لها على سياق كافٍ) ──────
  // نخزنها كقائمة نصوص JSON بسيطة حتى يسهل مراجعتها لاحقاً يدوياً.
  static Future<List<String>> getWeakQuestions() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_keyWeakQuestions);
    return raw ?? [];
  }

  static Future<void> addWeakQuestion(String question) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_keyWeakQuestions) ?? [];
    list.add(question);
    await prefs.setStringList(_keyWeakQuestions, list);
  }

  // ── تاريخ المحادثة ─────────────────────────────────────────
  static Future<void> saveChatHistory(List<ChatMessageData> messages) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(messages.map((m) => m.toJson()).toList());
    await prefs.setString(_keyChatHistory, encoded);
  }

  static Future<List<ChatMessageData>> loadChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyChatHistory);
    if (raw == null || raw.isEmpty) return [];
    final List decoded = jsonDecode(raw);
    return decoded.map((e) => ChatMessageData.fromJson(e)).toList();
  }

  static Future<void> clearChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyChatHistory);
  }

  // ── إعدادات أسماء النماذج (آخر نسخة تم جلبها بنجاح من GitHub) ──
  // نحفظها محلياً حتى إذا تعذّر الوصول لـ GitHub في فتحة تطبيق قادمة،
  // نستمر بآخر نسخة "معروفة وناجحة" بدل الرجوع للقيم الافتراضية
  // القديمة المضمّنة بالكود. هذا يجعل تغيير النموذج من GitHub تغييراً
  // دائماً وليس مؤقتاً مرتبطاً بنجاح الاتصال في كل مرة.
  static Future<void> saveModelConfig(Map<String, String> config) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyModelConfig, jsonEncode(config));
  }

  static Future<Map<String, String>?> getModelConfig() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyModelConfig);
    if (raw == null || raw.isEmpty) return null;
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    return decoded.map((key, value) => MapEntry(key, value as String));
  }
}