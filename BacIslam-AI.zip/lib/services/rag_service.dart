// ═══════════════════════════════════════════════════════════════
// rag_service.dart
// ─────────────────────────────────────────────────────────────
// هذا الملف يدير دورة حياة قاعدة معرفة RAG بالكامل، ومبني ليطابق
// بنية ملف rag_embeddings.jsonl الفعلية (كل سطر = كائن JSON فيه
// حقل "text" وليس "answer"، بالإضافة لحقول وصفية مثل lesson_title
// و subject لا نحتاجها إلزامياً لكنها مفيدة لعرض السياق).
//
//   1) checkAndDownloadUpdates -> يقارن رقم الإصدار المحلي بإصدار
//                                  GitHub، ويعيد تحميل الملف (نفس
//                                  الاسم الثابت دائماً) عند التغيّر.
//   2) loadEntries              -> يقرأ ملف JSONL المحلي سطراً بسطر.
//   3) findTopMatches           -> يحسب Cosine Similarity ويعيد
//                                  أفضل K مقاطع فوق عتبة معيّنة
//                                  (نفس فكرة TOP_K في الكود المرجعي).
//
// ⚠️ ملاحظة مهمة (مرحلة الاختبار الحالية):
//   لا يوجد أي تشفير على ملف RAG حالياً بطلب صريح منك، لأن التطبيق
//   في مرحلة اختبار. أي شخص يعرف رابط GitHub الخام يقدر يقرأ كل
//   محتوى قاعدة المعرفة مباشرة كنص عادي. أضف تشفيراً حقيقياً لاحقاً
//   قبل نشر التطبيق للعموم إذا كان المحتوى له قيمة تحب حمايتها.
// ═══════════════════════════════════════════════════════════════

import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'storage_service.dart';

class RagMatch {
  final String text; // نص المقطع (كان اسمه "answer" في التصميم القديم)
  final String lessonTitle;
  final String subject;
  final double similarity;

  RagMatch({
    required this.text,
    required this.similarity,
    this.lessonTitle = '',
    this.subject = '',
  });
}

class RagService {
  // ── إعدادات المستودع (حسب مستودعك الفعلي) ─────────────────
  static const String _repoBase =
      'https://raw.githubusercontent.com/Raoufsb/BacIslam-AI/refs/heads/main';
  static const String _versionUrl = '$_repoBase/version.txt';
  static const String _dataUrl = '$_repoBase/rag_embeddings.jsonl';

  // اسم الملف محلياً (ثابت؛ لا علاقة له برقم الإصدار)
  static const String _localFileName = 'rag_embeddings.jsonl';

  // ── إعدادات البحث (نفس قيم الكود المرجعي) ──────────────────
  static const int _topK = 3;
  static const double _similarityThreshold = 0.60; // أدنى حد للإدراج كسياق
  static const double _weakThreshold = 0.70; // دونه يُعتبر "تطابق ضعيف"

  static Future<String> _localFilePath() async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/$_localFileName';
  }

  /// الخطوة 2: يتحقق من إصدار GitHub، ويحمّل الملف الثابت الاسم عند
  /// تغيّر رقم الإصدار المحلي المخزَّن. يعيد true إذا كانت البيانات
  /// جاهزة ومحدّثة، و false إذا فشل الاتصال بالكامل.
  ///
  /// onProgress: دالة اختيارية تستدعى بنسبة التقدّم (0.0 إلى 1.0) أثناء
  /// تحميل الملف الكبير، لعرضها في شريط تحميل بواجهة المستخدم.
  static Future<bool> checkAndDownloadUpdates({
    void Function(double progress)? onProgress,
  }) async {
    try {
      final versionResponse = await http
          .get(Uri.parse(_versionUrl))
          .timeout(const Duration(seconds: 10));

      if (versionResponse.statusCode != 200) return false;

      final remoteVersion = versionResponse.body.trim();
      final localVersion = await StorageService.getLocalRagVersion();

      final localFile = File(await _localFilePath());
      final needsDownload =
          localVersion != remoteVersion || !(await localFile.exists());

      if (!needsDownload) {
        onProgress?.call(1.0);
        return true; // محدّث أصلاً
      }

      // نستخدم طلباً متدفقاً (streamed) حتى نقدر نحسب نسبة التقدّم
      // أثناء التحميل بدل انتظار الملف كاملاً بصمت.
      final request = http.Request('GET', Uri.parse(_dataUrl));
      final streamedResponse =
          await request.send().timeout(const Duration(seconds: 60));

      if (streamedResponse.statusCode != 200) return false;

      final total = streamedResponse.contentLength ?? 0;
      var received = 0;
      final bytes = <int>[];

      await for (final chunk in streamedResponse.stream) {
        bytes.addAll(chunk);
        received += chunk.length;
        if (total > 0) onProgress?.call(received / total);
      }

      await localFile.writeAsBytes(bytes, flush: true);
      await StorageService.setLocalRagVersion(remoteVersion);
      onProgress?.call(1.0);
      return true;
    } catch (e) {
      // فشل تحديث RAG لا يوقف التطبيق؛ نكمل بأحدث نسخة محلية موجودة.
      return false;
    }
  }

  /// الخطوة 3 (جزء أول): يقرأ ملف JSONL المحلي سطراً بسطر (بدون فك تشفير).
  static Future<List<Map<String, dynamic>>> loadEntries() async {
    try {
      final file = File(await _localFilePath());
      if (!await file.exists()) return [];

      final lines = await file.readAsLines();
      final entries = <Map<String, dynamic>>[];

      for (final line in lines) {
        final trimmed = line.trim();
        if (trimmed.isEmpty) continue;
        try {
          entries.add(jsonDecode(trimmed) as Map<String, dynamic>);
        } catch (_) {
          continue; // نتجاوز أي سطر تالف بدل تحطيم القراءة كاملة
        }
      }
      return entries;
    } catch (e) {
      return [];
    }
  }

  static double _cosineSimilarity(List<double> a, List<double> b) {
    if (a.length != b.length || a.isEmpty) return 0.0;
    double dot = 0, normA = 0, normB = 0;
    for (int i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    if (normA == 0 || normB == 0) return 0.0;
    return dot / (sqrt(normA) * sqrt(normB));
  }

  /// الخطوة 3 (جزء ثانٍ): يعيد أفضل K مقاطع فوق العتبة الدنيا، مرتّبة
  /// تنازلياً حسب التشابه. تُستخدم كسياق للنموذج عند بناء الإجابة.
  static List<RagMatch> findTopMatches(
    List<double> queryEmbedding,
    List<Map<String, dynamic>> entries, {
    int k = _topK,
  }) {
    final scored = <RagMatch>[];

    for (final entry in entries) {
      final rawEmbedding = entry['embedding'] as List?;
      if (rawEmbedding == null) continue;

      final embedding =
          rawEmbedding.map((e) => (e as num).toDouble()).toList();
      final sim = _cosineSimilarity(queryEmbedding, embedding);

      if (sim < _similarityThreshold) continue;

      scored.add(RagMatch(
        text: entry['text'] as String? ?? '',
        similarity: sim,
        lessonTitle: entry['lesson_title'] as String? ?? '',
        subject: entry['subject'] as String? ?? '',
      ));
    }

    scored.sort((a, b) => b.similarity.compareTo(a.similarity));
    return scored.take(k).toList();
  }

  /// يحدد إذا كان أفضل تطابق موجود "ضعيفاً" (دون عتبة الثقة العالية)،
  /// لتسجيل السؤال لاحقاً ومراجعته يدوياً (نفس منطق rag_weak في البوت).
  static bool isWeakMatch(List<RagMatch> matches) {
    if (matches.isEmpty) return true;
    return matches.first.similarity < _weakThreshold;
  }
}