// ═══════════════════════════════════════════════════════════════
// main.dart
// ─────────────────────────────────────────────────────────────
// نقطة انطلاق التطبيق. الدور الوحيد لهذا الملف هو تحديد الشاشة
// الأولى: إذا كان مفتاح API محفوظاً مسبقاً -> ChatScreen مباشرة،
// وإلا -> SetupScreen لإدخال المفتاح أولاً.
// ═══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';

import 'screens/loading_screen.dart';
import 'screens/setup_screen.dart';
import 'services/storage_service.dart';

void main() {
  runApp(const NoorBacApp());
}

class NoorBacApp extends StatelessWidget {
  const NoorBacApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'نور البكالوريا',
      debugShowCheckedModeBanner: false,
      // دعم اتجاه الكتابة من اليمين لليسار على مستوى التطبيق كاملاً
      locale: const Locale('ar'),
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        useMaterial3: true,
        fontFamily: 'Cairo', // إن أضفت خط Cairo لاحقاً في pubspec
      ),
      home: const _StartupGate(),
    );
  }
}

// ودجت بسيطة تقرر أي شاشة تُعرض أولاً بعد التحقق من التخزين المحلي.
class _StartupGate extends StatelessWidget {
  const _StartupGate();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String?>(
      future: StorageService.getApiKey(),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final hasKey = snapshot.data != null && snapshot.data!.isNotEmpty;
        return hasKey ? const LoadingScreen() : const SetupScreen();
      },
    );
  }
}